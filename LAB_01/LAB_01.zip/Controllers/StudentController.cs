﻿using Microsoft.AspNetCore.Mvc;

namespace LAB_01.Controllers
{
    public class StudentController : Controller
    {
        //private static List<Student> students;
        //public StudentController()
        //{
        //    students = new List<Student>
        //{
        //    new Student
        //    {
        //        Id = 1,
        //        Name = "John",
        //        Surname = "Doe",
        //        Index = 1001,
        //        BirthDate = new DateTime(2000, 5, 15),
        //        SubjectOfStudy = "Computer Science"
        //    },
        //    new Student
        //    {
        //        Id = 2,
        //        Name = "Jane",
        //        Surname = "Smith",
        //        Index = 1002,
        //        BirthDate = new DateTime(1999, 8, 22),
        //        SubjectOfStudy = "Electrical Engineering"
        //    },
        //    new Student
        //    {
        //        Id = 3,
        //        Name = "Alice",
        //        Surname = "Johnson",
        //        Index = 1003,
        //        BirthDate = new DateTime(2001, 11, 30),
        //        SubjectOfStudy = "Mathematics"
        //    },
        //    new Student
        //    {
        //        Id = 4,
        //        Name = "Bob",
        //        Surname = "Brown",
        //        Index = 1004,
        //        BirthDate = new DateTime(2000, 3, 10),
        //        SubjectOfStudy = "Physics"
        //    },
        //    new Student
        //    {
        //        Id = 5,
        //        Name = "Charlie",
        //        Surname = "Davis",
        //        Index = 1005,
        //        BirthDate = new DateTime(2002, 1, 25),
        //        SubjectOfStudy = "Chemistry"
        //    }
        //};
        //}
        //public IActionResult Index()
        //{
        //    return View(students);
        //}
        //public IActionResult ShowStudent(int id=1)
        //{
        //    return View("Student",students[id-1]);
        //}
    }
}
