﻿
using LAB02_DLL.Models;
using Microsoft.AspNetCore.Mvc;

namespace LAB_01.Controllers
{
    public class ArticleController : Controller
    {
        //public IActionResult Index(int id = 1)
        //{
        //    //var articleList = new List<Article>()
        //    //{
        //    //    new Article()
        //    //    {
        //    //        Id = 1,
        //    //        Title = "Article 1",
        //    //        Content = "Lorem ipsum...",
        //    //        CreationDate = DateTime.Now
        //    //    },
        //    //     new Article()
        //    //    {
        //    //        Id = 2,
        //    //        Title = "Article 2",
        //    //        Content = "Lorem ipsum...",
        //    //        CreationDate = DateTime.Now
        //    //    },
        //    //      new Article()
        //    //    {
        //    //        Id = 3,
        //    //        Title = "Article 3",
        //    //        Content = "Lorem ipsum...",
        //    //        CreationDate = DateTime.Now
        //    //    }
        //    //};
        //    //return View(articleList[id-1]);
        //}
    }
}
