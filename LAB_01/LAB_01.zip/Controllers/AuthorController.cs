﻿using LAB02_DLL.Context;
using LAB02_DLL.Models;
using Microsoft.AspNetCore.Mvc;

namespace LAB_01.Controllers
{
    public class AuthorController : Controller
    {
        private FootballDbContext _dbContext;
        public AuthorController(FootballDbContext footballDbContext) {
            _dbContext = footballDbContext;
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
